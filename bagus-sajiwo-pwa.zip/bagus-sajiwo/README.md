# Bagus Sajiwo — PWA Keuangan

## Struktur
index.html · style.css · app.js · manifest.json · sw.js · icons/

## Ukuran icon (folder icons/)
| File | Ukuran |
|---|---|
| icon-192.png | 192×192 |
| icon-512.png | 512×512 (juga maskable) |
| apple-touch-icon.png | 180×180 |
| favicon-32x32.png | 32×32 |
| favicon-16x16.png | 16×16 |
| favicon.ico | 16, 32, 48 px |

## Menjalankan
PWA wajib HTTPS (localhost boleh). Lokal: `python3 -m http.server 8080` lalu buka http://localhost:8080
Deploy: Cloudflare Pages/Workers, Vercel, Netlify, atau GitHub Pages — upload seluruh isi folder.

## Catatan
Data disimpan di localStorage perangkat (tanpa server). Gunakan Ekspor JSON di Laporan untuk cadangan.
Setelah mengubah file, naikkan versi CACHE di sw.js (mis. bagus-sajiwo-v2) agar cache diperbarui.
