'use strict';
const RATE=54,KEY='bagus-sajiwo-v1';
const IDR=['BCA','BNI','BRI','Mandiri','Seabank','Bank Jago','Neo Bank','Permata Bank','DANA','OVO','GoPay','LinkAja','Sakuku'];
const LKR=['Sampath Bank','Cash LKR'];
const CO=['Makanan','Transportasi','Tagihan','Belanja','Kesehatan','Hiburan','Pendidikan','Lainnya'];
const CI=['Gaji','Bonus','Usaha','Hadiah','Lainnya'];
const IC=['Pasar Modal','Perbankan & Surat Berharga','Logam Mulia'];
const DEF=()=>({tx:[],bud:{},inv:[],goals:[],custom:[],profile:{name:'',email:''},set:{hide:false,notif:true,cur:'IDR'}});
let S;try{S=Object.assign(DEF(),JSON.parse(localStorage.getItem(KEY)))}catch(e){S=DEF()}
let F={type:'',cat:''},deferred=null;
const $=(s,r=document)=>r.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const save=()=>localStorage.setItem(KEY,JSON.stringify(S));
const today=()=>new Date().toISOString().slice(0,10);
const accs=()=>[...IDR.map(n=>({n,c:'IDR'})),...LKR.map(n=>({n,c:'LKR'})),...S.custom];
const accCur=n=>(accs().find(a=>a.n===n)||{}).c||'IDR';
const f=(v,c)=>(c==='IDR'?'Rp':'Rs')+(+v).toLocaleString('id-ID',{maximumFractionDigits:c==='IDR'?0:2});
const m=(v,c=S.set.cur)=>S.set.hide?'••••':f(v,c);
const conv=(v,from,to=S.set.cur)=>from===to?v:from==='LKR'?v*RATE:v/RATE;
const toast=t=>{if(!S.set.notif)return;const e=$('#toast');e.textContent=t;e.classList.add('on');setTimeout(()=>e.classList.remove('on'),2200)};
function balances(){const b={};accs().forEach(a=>b[a.n]=0);S.tx.forEach(t=>{if(t.type==='fx'){b[t.from]=(b[t.from]||0)-t.amt;b[t.to]=(b[t.to]||0)+t.got}else b[t.acc]=(b[t.acc]||0)+(t.type==='in'?t.amt:-t.amt)});return b}
const net=(c=S.set.cur)=>{const b=balances();return accs().reduce((s,a)=>s+conv(b[a.n]||0,a.c,c),0)};
const sum=(type,list=S.tx)=>list.filter(t=>t.type===type).reduce((s,t)=>s+conv(t.amt,t.cur),0);
const monthTx=()=>S.tx.filter(t=>t.date.slice(0,7)===today().slice(0,7));
function byCat(list){const o={};list.filter(t=>t.type==='out').forEach(t=>o[t.cat]=(o[t.cat]||0)+conv(t.amt,t.cur));return Object.entries(o).sort((a,b)=>b[1]-a[1])}
const bar=(p,cls='')=>`<div class="bar"><i class="${cls}" style="width:${Math.min(100,Math.max(0,p))}%"></i></div>`;
const catRows=(arr,c)=>{const mx=arr.length?arr[0][1]:1;return arr.length?arr.map(([k,v])=>`<div><div class="row" style="border:0;padding:3px 0"><span>${esc(k)}</span><b>${m(v,c)}</b></div>${bar(v/mx*100)}</div>`).join(''):'<p class="mute">Belum ada pengeluaran.</p>'};

function vDash(){
 const c=S.set.cur,inc=sum('in'),out=sum('out'),tot=inc+out||1,mt=monthTx();
 const list=S.tx.filter(t=>(!F.type||t.type===F.type)&&(!F.cat||t.cat===F.cat)).sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
 return `<div class="card hero"><div class="mute">Total Saldo (Net Worth)</div><div class="big">${m(net(),c)}</div>
 <div class="mute">Kurs acuan tetap 1 LKR = ${RATE} IDR</div></div>
 <div class="grid"><div class="card"><div class="mute">Pemasukan</div><h3 class="in">${m(inc,c)}</h3></div><div class="card"><div class="mute">Pengeluaran</div><h3 class="out">${m(out,c)}</h3></div></div>
 <div class="grid"><div class="card"><h3>Pemasukan vs Pengeluaran</h3>${bar(inc/tot*100,'g')}${bar(out/tot*100,'r')}<div class="mute">Bulan ini: +${m(sum('in',mt),c)} / −${m(sum('out',mt),c)}</div></div>
 <div class="card"><h3>Kategori Teratas</h3>${catRows(byCat(mt).slice(0,4),c)}</div></div>
 <div class="card"><h3>Saldo per Akun</h3>${vBal(true)}</div>
 <div class="card"><h3>Riwayat Transaksi</h3><div class="filters"><select data-f="type"><option value="">Semua Jenis</option><option value="in" ${F.type==='in'?'selected':''}>Pemasukan</option><option value="out" ${F.type==='out'?'selected':''}>Pengeluaran</option><option value="fx" ${F.type==='fx'?'selected':''}>Tukar Kurs</option></select>
 <select data-f="cat"><option value="">Semua Kategori</option>${[...new Set([...CI,...CO])].map(k=>`<option ${F.cat===k?'selected':''}>${k}</option>`).join('')}</select></div>
 ${list.length?list.map(t=>t.type==='fx'?`<div class="row"><div>🔁 Tukar ${esc(t.from)} → ${esc(t.to)}<small>${t.date} · kurs ${t.rate}</small></div><div>${m(t.amt,accCur(t.from))} → ${m(t.got,accCur(t.to))} <button class="x" data-act="deltx" data-id="${t.id}">✕</button></div></div>`
 :`<div class="row"><div>${esc(t.name)}<small>${esc(t.cat)} · ${esc(t.acc)} · ${t.date}</small></div><div class="${t.type}">${t.type==='in'?'+':'−'}${m(t.amt,t.cur)} <button class="x" data-act="deltx" data-id="${t.id}">✕</button></div></div>`).join(''):'<p class="mute">Belum ada transaksi. Klik “+ Transaksi”.</p>'}</div>`}
function vBal(short){
 const b=balances(),grp=c=>accs().filter(a=>a.c===c);
 const g=(c,t)=>`<div class="card" style="${short?'padding:0;border:0;background:none':''}"><div class="mute">${t}</div>${grp(c).filter(a=>!short||b[a.n]).map(a=>`<div class="row"><span>${esc(a.n)}</span><b class="${b[a.n]<0?'out':''}">${m(b[a.n]||0,c)}</b></div>`).join('')||'<p class="mute">—</p>'}</div>`;
 return `<div class="grid">${g('IDR','Kantong Indonesia (IDR)')}${g('LKR','Kantong Sri Lanka (LKR)')}</div>`}
function vRek(){return `<div class="card hero"><div class="mute">Net Worth</div><div class="big">${m(net(),S.set.cur)}</div></div>${vBal(false)}
 <div class="card"><h3>Tambah Bank / E-Wallet</h3><form data-form="acc" class="grid"><label>Nama akun<input name="n" required></label><label>Mata uang<select name="c"><option>IDR</option><option>LKR</option></select></label><div><button class="btn">Tambah</button></div></form></div>`}
function vLap(){const c=S.set.cur,inc=sum('in'),out=sum('out'),tot=inc+out||1;
 return `<div class="grid"><div class="card"><h3>Distribusi Keuangan</h3>${bar(inc/tot*100,'g')}<div class="row"><span>Pemasukan</span><b class="in">${m(inc,c)}</b></div>${bar(out/tot*100,'r')}<div class="row"><span>Pengeluaran</span><b class="out">${m(out,c)}</b></div><div class="row"><span>Saldo Bersih</span><b>${m(inc-out,c)}</b></div></div>
 <div class="card"><h3>Rincian per Kategori</h3>${catRows(byCat(S.tx),c)}</div></div>
 <div class="card"><button class="btn g" data-act="export">⬇ Ekspor data (JSON)</button></div>`}
function vBud(){const c=S.set.cur,used=Object.fromEntries(byCat(monthTx()));
 return `<div class="card"><p class="mute" style="margin-bottom:12px">Batas anggaran bulanan per kategori dalam Rupiah (IDR). Pemakaian dihitung dari pengeluaran bulan ini.</p>${CO.map(k=>{const lim=+S.bud[k]||0,u=conv(used[k]||0,c,'IDR'),p=lim?u/lim*100:0;
 return `<div style="margin-bottom:14px"><div class="row" style="border:0"><b>${k}</b><span class="mute">${m(conv(u,'IDR',c),c)} / ${lim?m(conv(lim,'IDR',c),c):'tanpa batas'}</span></div>${bar(p,p>=100?'r':'')}<input type="number" min="0" data-bud="${k}" placeholder="Batas (Rp)" value="${lim||''}"></div>`}).join('')}</div>`}
function vInv(){
 return `<div class="card"><h3>Tambah Investasi Baru</h3><form data-form="inv" class="grid"><label>Kategori<select name="k">${IC.map(x=>`<option>${x}</option>`).join('')}</select></label><label>Nama Instrumen<input name="n" required></label><label>Jumlah Saldo (Unit)<input name="q" type="number" step="any" min="0.0001" required></label><label>Harga Beli (Rp)<input name="p" type="number" step="any" min="1" required></label><label>Tanggal Beli<input name="d" type="date" value="${today()}" required></label><div><button class="btn">Simpan Investasi</button></div></form></div>
 ${IC.map(k=>{const l=S.inv.filter(i=>i.k===k);return `<details ${l.length?'open':''}><summary>${k} (${l.length})</summary>${l.map(i=>`<div class="row"><div>${esc(i.n)}<small>${i.q} unit · ${i.d}</small></div><div>${m(i.p,'IDR')} <button class="x" data-act="delinv" data-id="${i.id}">✕</button></div></div>`).join('')||'<p>Belum ada catatan.</p>'}</details>`}).join('')}`}
function vGoal(){
 return `<div class="row" style="border:0"><p class="mute">Progres dihitung dari total saldo gabungan (IDR + LKR) × alokasi.</p><button class="btn" data-act="goal">+ Target</button></div>
 ${S.goals.map(g=>{const saved=net(g.cur)*g.alloc/100,p=g.target?saved/g.target*100:0,[y,mo]=g.month.split('-').map(Number),n=new Date(),left=Math.max(1,(y-n.getFullYear())*12+mo-(n.getMonth()+1)),need=Math.max(0,(g.target-saved)/left);
 return `<div class="card"><div class="row" style="border:0"><h3>${esc(g.name)}</h3><button class="x" data-act="delgoal" data-id="${g.id}">✕</button></div>${bar(p,p>=100?'g':'')}<div class="row"><span>Terkumpul</span><b>${m(saved,g.cur)} / ${m(g.target,g.cur)} (${Math.min(100,p).toFixed(0)}%)</b></div>
 <div class="mute">${p>=100?'🎉 Target Tercapai! Selamat!':`Wajib menabung ${m(need,g.cur)}/bulan selama ${left} bulan (target ${g.month})`}</div></div>`}).join('')||'<div class="card mute">Belum ada target.</div>'}`}
const TIPS=[['Menabung','Mulai dari Konsisten','Menabung kecil tapi rutin lebih efektif daripada menunggu uang "lebih".'],['Dana Darurat','Siapkan Dulu Sebelum Investasi','Idealnya 3–6× pengeluaran bulanan agar tidak perlu berutang saat darurat.'],['Perilaku Konsumtif','Waspadai Belanja Impulsif','Beri jeda 24 jam sebelum membeli barang non-esensial.'],['Utang','Hindari Utang Gaya Hidup','Gunakan utang hanya untuk hal produktif yang hasilnya melebihi bunga.'],['Anggaran','Aturan 50/30/20','50% kebutuhan, 30% keinginan, 20% tabungan/investasi.'],['Gaya Hidup','Jangan Ikut-ikutan','Fokus pada tujuan keuanganmu sendiri, bukan standar media sosial.']];
const vEdu=()=>`<div class="grid">${TIPS.map(t=>`<div class="card"><div class="mute">${t[0]}</div><h3>${t[1]}</h3><p class="mute">${t[2]}</p></div>`).join('')}</div>`;
const vGuide=()=>`<div class="card">
<details open><summary>1. Sistem Dua Kantong</summary><p>Saldo dipisah: Kantong Indonesia (IDR: bank & e-wallet) dan Kantong Sri Lanka (LKR: Sampath Bank & Cash LKR). Transaksi hanya mengubah saldo akun sesuai mata uangnya.</p></details>
<details><summary>2. Toggle IDR / LKR</summary><p>Hanya mengubah tampilan angka gabungan memakai kurs acuan 1 LKR = ${RATE} IDR. Data tidak berubah.</p></details>
<details><summary>3. Tukar Kurs</summary><p>Tambah Transaksi → tab Tukar Kurs → pilih akun asal & tujuan, isi nominal dan kurs hari itu. Saldo kedua akun diperbarui otomatis.</p></details>
<details><summary>4. Anggaran, Investasi & Target</summary><p>Atur batas per kategori, catat investasi, dan buat target dengan simulasi tabungan per bulan.</p></details>
<details><summary>5. Instal Aplikasi</summary><p><b>Android (Chrome):</b> menu ⋮ → Instal aplikasi.<br><b>iPhone (Safari):</b> Share → Tambahkan ke Layar Utama.</p></details>
<details><summary>6. Penyimpanan Data</summary><p>Data tersimpan di perangkat ini (localStorage). Gunakan Ekspor di halaman Laporan untuk cadangan.</p></details></div>`;
const vProf=()=>`<div class="card"><form data-form="prof"><label>Nama Pengguna<input name="name" value="${esc(S.profile.name)}"></label><label>Email (opsional)<input name="email" type="email" value="${esc(S.profile.email)}"></label><button class="btn">Simpan Profil</button></form></div>
<div class="card"><h3>Preferensi Tampilan</h3><label><input type="checkbox" data-set="hide" ${S.set.hide?'checked':''}> Sembunyikan nominal saldo</label><label><input type="checkbox" data-set="notif" ${S.set.notif?'checked':''}> Notifikasi transaksi berhasil</label></div>
<div class="card"><h3>Zona Berbahaya</h3><p class="mute" style="margin-bottom:10px">Menghapus semua data bersifat permanen.</p><button class="btn d" data-act="reset">Hapus Semua Data</button></div>`;

const R={dashboard:['🏠','Dashboard','Ringkasan keuangan kamu hari ini',vDash],rekening:['🏦','Rekening & E-Wallet','Saldo tiap akun',vRek],laporan:['📊','Laporan & Analitik','Distribusi pemasukan & pengeluaran',vLap],anggaran:['🎯','Anggaran','Batas pengeluaran bulanan',vBud],investasi:['📈','Investasi','Catatan portofolio',vInv],target:['⭐','Target & Impian','Rencanakan tujuan keuanganmu',vGoal],edukasi:['📚','Edukasi Finansial','Kenapa literasi finansial penting?',vEdu],panduan:['❓','Panduan Pengguna','Cara memakai aplikasi',vGuide],profil:['⚙️','Profil & Pengaturan','Atur akun & tampilan',vProf]};
const SHORT=['dashboard','rekening','target','laporan','profil'];
function render(){const k=R[location.hash.slice(1)]?location.hash.slice(1):'dashboard',r=R[k];
 $('#view').innerHTML=`<h1>${r[1]}</h1><p class="sub">${r[2]}</p>`+r[3]();
 $('#nav').innerHTML=Object.entries(R).map(([h,v])=>`<a href="#${h}" class="${h===k?'on':''}"><span>${v[0]}</span> ${v[1]}</a>`).join('');
 $('#bnav').innerHTML=SHORT.map(h=>`<a href="#${h}" class="${h===k?'on':''}"><span>${R[h][0]}</span>${R[h][1].split(' ')[0]}</a>`).join('')+`<a href="#anggaran" class="${['anggaran','investasi','edukasi','panduan'].includes(k)?'on':''}"><span>☰</span>Lainnya</a>`;
 document.querySelectorAll('#curseg button').forEach(b=>b.classList.toggle('on',b.dataset.c===S.set.cur));window.scrollTo(0,0)}
addEventListener('hashchange',render);

const fxGot=(a,from,to,rate)=>{const fc=accCur(from),tc=accCur(to);return fc===tc?a:fc==='IDR'?a/rate:a*rate};
function txForm(type){const fx=type==='fx',o=(l)=>l.map(a=>`<option>${esc(a.n)}</option>`).join('');
 return `<div class="tabs">${[['in','Pemasukan'],['out','Pengeluaran'],['fx','Tukar Kurs']].map(([k,l])=>`<button type="button" data-act="txtab" data-t="${k}" class="${k===type?'on':''}">${l}</button>`).join('')}</div>
 <form data-form="tx"><input type="hidden" name="type" value="${type}">`+(fx?
 `<label>Akun Asal<select name="from">${o(accs())}</select></label><label>Akun Tujuan<select name="to">${o(accs())}</select></label><label>Jumlah yang Dilepas<input name="amt" type="number" step="any" min="0.01" required></label><label>Kurs hari ini (1 LKR = ? IDR)<input name="rate" type="number" step="any" min="0.01" value="${RATE}" required></label><p class="mute" id="pv" style="margin-bottom:10px"></p>`:
 `<label>Nama Transaksi<input name="name" required></label><label>Mata Uang<select name="cur"><option>IDR</option><option>LKR</option></select></label><label>Nominal<input name="amt" type="number" step="any" min="0.01" required></label><label>Kategori<select name="cat">${(type==='in'?CI:CO).map(x=>`<option>${x}</option>`).join('')}</select></label><label>Sumber Dana / Akun<select name="acc">${o(accs().filter(a=>a.c==='IDR'))}</select></label>`)+
 `<label>Tanggal<input name="date" type="date" value="${today()}" required></label><div class="acts"><button type="button" class="btn g" data-act="close">Batal</button><button class="btn">Simpan Transaksi</button></div></form>`}
const openDlg=h=>{const d=$('#dlg');d.innerHTML=h;d.showModal?d.showModal():d.setAttribute('open','')};
const closeDlg=()=>{const d=$('#dlg');d.close?d.close():d.removeAttribute('open')};

document.addEventListener('click',e=>{const el=e.target.closest('[data-act]');if(!el)return;const a=el.dataset.act,id=+el.dataset.id;
 if(a==='tx')openDlg(txForm('out'));
 else if(a==='txtab')openDlg(txForm(el.dataset.t));
 else if(a==='close')closeDlg();
 else if(a==='curr'){S.set.cur=el.dataset.c;save();render()}
 else if(a==='deltx'){S.tx=S.tx.filter(t=>t.id!==id);save();render()}
 else if(a==='delinv'){S.inv=S.inv.filter(t=>t.id!==id);save();render()}
 else if(a==='delgoal'){S.goals=S.goals.filter(t=>t.id!==id);save();render()}
 else if(a==='goal')openDlg(`<h3>Tambah Target Baru</h3><form data-form="goal"><label>Nama Target<input name="name" required></label><label>Mata Uang<select name="cur"><option>IDR</option><option>LKR</option></select></label><label>Nominal Target<input name="target" type="number" min="1" step="any" required></label><label>Alokasi Saldo (%)<input name="alloc" type="number" min="1" max="100" value="100" required></label><label>Target Waktu<input name="month" type="month" required></label><div class="acts"><button type="button" class="btn g" data-act="close">Batal</button><button class="btn">Simpan Target</button></div></form>`);
 else if(a==='export'){const l=document.createElement('a');l.href=URL.createObjectURL(new Blob([JSON.stringify(S,null,2)],{type:'application/json'}));l.download='bagus-sajiwo-backup.json';l.click()}
 else if(a==='reset'){if(confirm('Hapus SEMUA data? Tindakan ini tidak bisa dibatalkan.')){S=DEF();save();render();toast('Data dihapus')}}
 else if(a==='install'&&deferred){deferred.prompt();deferred=null;$('#inst').hidden=true}});

document.addEventListener('submit',e=>{const fm=e.target.dataset.form;if(!fm)return;e.preventDefault();const d=Object.fromEntries(new FormData(e.target)),id=Date.now();
 if(fm==='tx'){d.amt=+d.amt;d.id=id;
  if(d.type==='fx'){if(d.from===d.to)return alert('Akun tujuan harus berbeda dari akun asal');d.rate=+d.rate;d.got=fxGot(d.amt,d.from,d.to,d.rate)}
  S.tx.push(d);save();closeDlg();render();toast('Transaksi disimpan ✓')}
 else if(fm==='inv'){S.inv.push({id,k:d.k,n:d.n,q:+d.q,p:+d.p,d:d.d});save();render();toast('Investasi disimpan ✓')}
 else if(fm==='goal'){S.goals.push({id,name:d.name,cur:d.cur,target:+d.target,alloc:+d.alloc,month:d.month});save();closeDlg();render()}
 else if(fm==='acc'){if(accs().some(a=>a.n.toLowerCase()===d.n.trim().toLowerCase()))return alert('Nama akun sudah ada');S.custom.push({n:d.n.trim(),c:d.c});save();render()}
 else if(fm==='prof'){S.profile=d;save();toast('Profil disimpan ✓')}});

document.addEventListener('change',e=>{const t=e.target;
 if(t.dataset.f){F[t.dataset.f]=t.value;render()}
 else if(t.dataset.bud){S.bud[t.dataset.bud]=+t.value||0;save();render()}
 else if(t.dataset.set){S.set[t.dataset.set]=t.checked;save();render()}
 else if(t.name==='cur'&&t.form?.dataset.form==='tx'){const s=t.form.acc;s.innerHTML=accs().filter(a=>a.c===t.value).map(a=>`<option>${esc(a.n)}</option>`).join('')}});
document.addEventListener('input',e=>{const fm=e.target.form;if(!fm||fm.dataset.form!=='tx'||fm.type.value!=='fx')return;
 const a=+fm.amt.value||0,r=+fm.rate.value||0,g=fxGot(a,fm.from.value,fm.to.value,r);$('#pv').textContent=`${f(a,accCur(fm.from.value))} → ${f(g,accCur(fm.to.value))}`});

addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferred=e;$('#inst').hidden=false});
addEventListener('appinstalled',()=>$('#inst').hidden=true);
if('serviceWorker'in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
render();
